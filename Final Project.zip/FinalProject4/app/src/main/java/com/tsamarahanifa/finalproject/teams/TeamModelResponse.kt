package com.tsamarahanifa.finalproject.teams

data class TeamModelResponse (
        val teams: List<TeamModel>


)