package com.tsamarahanifa.finalproject.leagues

data class LeagueModelResponse (
        val leagues: List<LeagueModel>


)