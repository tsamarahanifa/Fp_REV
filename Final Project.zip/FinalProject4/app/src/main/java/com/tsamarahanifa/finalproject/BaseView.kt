package com.tsamarahanifa.finalproject

interface BaseView {
    fun showLoading()
    fun hideLoading()
}